<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="m-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="m-4" style="text-align: center">
        <a href="<?php echo e(url('createCompany')); ?>" class="btn btn-success">Add New Company</a>
        <a href="<?php echo e(url('createEmploy')); ?>" class="btn btn-success">Add New Employ</a>
        <a href="<?php echo e(url('CompanyList')); ?>" class="btn btn-success">Company List</a>
        <a href="<?php echo e(url('EmployList')); ?>" class="btn btn-success">Employ List</a>
    </div>
        <div class="m-4" style="text-align: center">
            <h4>Company Table</h4>
        </div>
        <table class="table table-dark table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Total Employ</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $number = 1; ?>
            <?php $__currentLoopData = $Company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($number); ?></td>
                    <?php $number++; ?>
                    <td><?php echo e($Company->Name); ?></td>
                    <td><?php echo e($Company->Email); ?></td>
                    <td><?php echo e($Company->Phone); ?></td>
                    <td><a href="<?php echo e(url('Count',$Company->id)); ?>" class="btn btn-success">Count</a>
                    </td>
                    <td> <a href="<?php echo e(url('EditCom',$Company->id)); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('DeleteCom',$Company->id)); ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="m-4" style="text-align: center">
            <h4>Employ Table</h4>
        </div>
        <table class="table table-dark">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Company</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $number = 1; ?>
            <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($number); ?></td>
                    <?php $number++; ?>
                    <td><?php echo e($Employee->FirstName); ?> <?php echo e($Employee->LastName); ?></td>
                    <td><?php echo e($Employee->Company); ?></td>
                    <td><?php echo e($Employee->Email); ?></td>
                    <td><?php echo e($Employee->Phone); ?></td>
                    <td> <a href="<?php echo e(url('EditEm',$Employee->id)); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('DeleteEm',$Employee->id)); ?>" class="btn btn-danger">Delete</a>
                    </td>


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
</div>
</body>
</html>
<?php /**PATH J:\exam\resources\views/index.blade.php ENDPATH**/ ?>